# TEST MITRA - GitHub APK Ready

This project is prepared for a GitHub Actions debug APK build.

## GitHub
1. Upload/extract this ZIP into a GitHub repository so `app/`, `gradle/`, `build.gradle.kts`, `settings.gradle.kts`, and `.github/` are at repository root.
2. Open **Actions**.
3. Select **TEST MITRA - Build APK**.
4. Click **Run workflow**.
5. Open the completed run and download the **TEST-MITRA-APK** artifact.

The workflow downloads the required Gradle version itself, so a Gradle wrapper is not required.
