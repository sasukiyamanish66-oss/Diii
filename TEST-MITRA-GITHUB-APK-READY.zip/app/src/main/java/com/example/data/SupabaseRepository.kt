package com.example.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.BuildConfig
import com.example.model.AnnouncementItem
import com.example.model.ExamType
import com.example.model.QuestionItem
import com.example.model.TestItem
import com.example.model.UserProfile
import com.example.model.UserRole
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.TimeUnit

sealed class AuthResult {
    data class Success(val user: UserProfile, val sessionToken: String) : AuthResult()
    data class Error(val message: String) : AuthResult()
}

class SupabaseRepository(private val context: Context) {

    private val sessionManager = SessionManager(context)
    private val persistentPrefs: SharedPreferences =
        context.getSharedPreferences("test_mitra_persistent_store", Context.MODE_PRIVATE)

    private val client = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(12, TimeUnit.SECONDS)
        .build()

    private val supabaseUrl: String
        get() = try {
            val url = BuildConfig.SUPABASE_URL
            if (url.isNotBlank() && url.startsWith("http") && !url.contains("xyzcompany")) {
                url.trimEnd('/')
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }

    private val supabaseKey: String
        get() = try {
            val key = BuildConfig.SUPABASE_ANON_KEY
            if (key.isNotBlank() && !key.contains("dummy")) {
                key
            } else {
                ""
            }
        } catch (e: Exception) {
            ""
        }

    // In-memory synced state backed by persistent storage and remote Supabase
    private val localUsers = mutableListOf<UserProfile>()
    private val localTests = mutableListOf<TestItem>()
    private val localAnnouncements = mutableListOf<AnnouncementItem>()

    companion object {
        private const val KEY_STORED_USERS = "stored_users_json"
        private const val KEY_STORED_TESTS = "stored_tests_json"
        private const val KEY_STORED_ANNOUNCEMENTS = "stored_announcements_json"
    }

    init {
        loadFromPersistentCache()
        // Sync with remote server in background
        CoroutineScope(Dispatchers.IO).launch {
            syncAllWithRemote()
        }
    }

    // --- Persistence Management (Survives App Close & Logout) ---

    @Synchronized
    private fun loadFromPersistentCache() {
        localUsers.clear()
        localTests.clear()
        localAnnouncements.clear()

        // 1. Load users
        val usersJsonStr = persistentPrefs.getString(KEY_STORED_USERS, null)
        if (!usersJsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(usersJsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    localUsers.add(
                        UserProfile(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            mobile = obj.optString("mobile", ""),
                            passwordHash = obj.optString("password_hash", ""),
                            fullName = obj.optString("full_name", ""),
                            role = UserRole.fromString(obj.optString("role", "student")),
                            examType = obj.optString("exam_type", "").takeIf { it.isNotBlank() && it != "null" }?.let { ExamType.fromString(it) },
                            isActive = obj.optBoolean("is_active", true),
                            sessionToken = obj.optString("session_token", "").takeIf { it.isNotBlank() && it != "null" },
                            createdAt = obj.optString("created_at", "")
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Error reading cached users: ${e.message}")
            }
        }

        // Ensure Admin user always exists (No demo students seeded)
        val adminExists = localUsers.any { it.role == UserRole.ADMIN }
        if (!adminExists) {
            localUsers.add(
                0,
                UserProfile(
                    id = "admin-1",
                    mobile = "7096684982",
                    passwordHash = "Manish@2006",
                    fullName = "Manish",
                    role = UserRole.ADMIN,
                    examType = null,
                    isActive = true,
                    createdAt = "2026-08-13"
                )
            )
            saveUsersToCache()
        }

        // 2. Load tests (No demo tests seeded)
        val testsJsonStr = persistentPrefs.getString(KEY_STORED_TESTS, null)
        if (!testsJsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(testsJsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val qArray = obj.optJSONArray("questions") ?: JSONArray()
                    val questions = mutableListOf<QuestionItem>()
                    for (j in 0 until qArray.length()) {
                        val qObj = qArray.getJSONObject(j)
                        questions.add(
                            QuestionItem(
                                id = qObj.optString("id", UUID.randomUUID().toString()),
                                testId = qObj.optString("test_id", obj.optString("id")),
                                questionText = qObj.optString("question_text", ""),
                                optionA = qObj.optString("option_a", ""),
                                optionB = qObj.optString("option_b", ""),
                                optionC = qObj.optString("option_c", ""),
                                optionD = qObj.optString("option_d", ""),
                                correctOption = qObj.optInt("correct_option", 0),
                                explanation = qObj.optString("explanation", ""),
                                orderIndex = qObj.optInt("order_index", j + 1)
                            )
                        )
                    }
                    localTests.add(
                        TestItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                            title = obj.optString("title", ""),
                            durationMinutes = obj.optInt("duration_minutes", 30),
                            isActive = obj.optBoolean("is_active", true),
                            questions = questions,
                            createdAt = obj.optString("created_at", "")
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Error reading cached tests: ${e.message}")
            }
        }

        // 3. Load announcements
        val annJsonStr = persistentPrefs.getString(KEY_STORED_ANNOUNCEMENTS, null)
        if (!annJsonStr.isNullOrBlank()) {
            try {
                val array = JSONArray(annJsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    localAnnouncements.add(
                        AnnouncementItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            title = obj.optString("title", ""),
                            message = obj.optString("message", ""),
                            examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                            date = obj.optString("date", ""),
                            isActive = obj.optBoolean("is_active", true),
                            isImportant = obj.optBoolean("is_important", false)
                        )
                    )
                }
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Error reading cached announcements: ${e.message}")
            }
        }
    }

    @Synchronized
    private fun saveUsersToCache() {
        try {
            val array = JSONArray()
            for (u in localUsers) {
                val obj = JSONObject().apply {
                    put("id", u.id)
                    put("mobile", u.mobile)
                    put("password_hash", u.passwordHash)
                    put("full_name", u.fullName)
                    put("role", u.role.name.lowercase())
                    put("exam_type", u.examType?.id)
                    put("is_active", u.isActive)
                    put("session_token", u.sessionToken)
                    put("created_at", u.createdAt)
                }
                array.put(obj)
            }
            persistentPrefs.edit().putString(KEY_STORED_USERS, array.toString()).apply()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Error saving users cache: ${e.message}")
        }
    }

    @Synchronized
    private fun saveTestsToCache() {
        try {
            val array = JSONArray()
            for (t in localTests) {
                val testObj = JSONObject().apply {
                    put("id", t.id)
                    put("exam_type", t.examType.id)
                    put("title", t.title)
                    put("duration_minutes", t.durationMinutes)
                    put("is_active", t.isActive)
                    put("created_at", t.createdAt)

                    val qArray = JSONArray()
                    for (q in t.questions) {
                        val qObj = JSONObject().apply {
                            put("id", q.id)
                            put("test_id", t.id)
                            put("question_text", q.questionText)
                            put("option_a", q.optionA)
                            put("option_b", q.optionB)
                            put("option_c", q.optionC)
                            put("option_d", q.optionD)
                            put("correct_option", q.correctOption)
                            put("explanation", q.explanation)
                            put("order_index", q.orderIndex)
                        }
                        qArray.put(qObj)
                    }
                    put("questions", qArray)
                }
                array.put(testObj)
            }
            persistentPrefs.edit().putString(KEY_STORED_TESTS, array.toString()).apply()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Error saving tests cache: ${e.message}")
        }
    }

    @Synchronized
    private fun saveAnnouncementsToCache() {
        try {
            val array = JSONArray()
            for (a in localAnnouncements) {
                val obj = JSONObject().apply {
                    put("id", a.id)
                    put("title", a.title)
                    put("message", a.message)
                    put("exam_type", a.examType.id)
                    put("date", a.date)
                    put("is_active", a.isActive)
                    put("is_important", a.isImportant)
                }
                array.put(obj)
            }
            persistentPrefs.edit().putString(KEY_STORED_ANNOUNCEMENTS, array.toString()).apply()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Error saving announcements cache: ${e.message}")
        }
    }

    // --- Remote Supabase Synchronization ---

    suspend fun syncAllWithRemote() = withContext(Dispatchers.IO) {
        if (supabaseUrl.isBlank() || supabaseKey.isBlank()) return@withContext

        // 1. Sync Admin profile to Supabase
        try {
            val admin = localUsers.firstOrNull { it.role == UserRole.ADMIN }
            if (admin != null) {
                val url = "$supabaseUrl/rest/v1/profiles"
                val json = JSONObject().apply {
                    put("id", admin.id)
                    put("mobile", admin.mobile)
                    put("password_hash", admin.passwordHash)
                    put("full_name", admin.fullName)
                    put("role", "admin")
                    put("is_active", true)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .addHeader("Prefer", "resolution=merge-duplicates")
                    .post(body)
                    .build()
                client.newCall(request).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Sync admin error: ${e.message}")
        }

        // 2. Fetch Profiles from Supabase
        try {
            val url = "$supabaseUrl/rest/v1/profiles?select=*"
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .get()
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val array = JSONArray(body)
                if (array.length() > 0) {
                    val remoteStudents = mutableListOf<UserProfile>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val roleStr = obj.optString("role", "student")
                        val role = UserRole.fromString(roleStr)
                        if (role == UserRole.STUDENT) {
                            remoteStudents.add(
                                UserProfile(
                                    id = obj.optString("id", UUID.randomUUID().toString()),
                                    mobile = obj.optString("mobile", ""),
                                    passwordHash = obj.optString("password_hash", ""),
                                    fullName = obj.optString("full_name", ""),
                                    role = UserRole.STUDENT,
                                    examType = obj.optString("exam_type", "").takeIf { it.isNotBlank() && it != "null" }?.let { ExamType.fromString(it) },
                                    isActive = obj.optBoolean("is_active", true),
                                    sessionToken = obj.optString("session_token", "").takeIf { it.isNotBlank() && it != "null" },
                                    createdAt = obj.optString("created_at", "")
                                )
                            )
                        }
                    }
                    synchronized(this@SupabaseRepository) {
                        val admin = localUsers.firstOrNull { it.role == UserRole.ADMIN }
                        localUsers.clear()
                        if (admin != null) localUsers.add(admin)
                        localUsers.addAll(remoteStudents)
                        saveUsersToCache()
                    }
                }
            }
            response.close()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Fetch profiles error: ${e.message}")
        }

        // 3. Fetch Tests and Questions from Supabase
        try {
            val url = "$supabaseUrl/rest/v1/tests?select=*,questions(*)"
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .get()
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val array = JSONArray(body)
                val remoteTests = mutableListOf<TestItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val qArray = obj.optJSONArray("questions") ?: JSONArray()
                    val qList = mutableListOf<QuestionItem>()
                    for (j in 0 until qArray.length()) {
                        val qObj = qArray.getJSONObject(j)
                        qList.add(
                            QuestionItem(
                                id = qObj.optString("id", UUID.randomUUID().toString()),
                                testId = qObj.optString("test_id", obj.optString("id")),
                                questionText = qObj.optString("question_text", ""),
                                optionA = qObj.optString("option_a", ""),
                                optionB = qObj.optString("option_b", ""),
                                optionC = qObj.optString("option_c", ""),
                                optionD = qObj.optString("option_d", ""),
                                correctOption = qObj.optInt("correct_option", 0),
                                explanation = qObj.optString("explanation", ""),
                                orderIndex = qObj.optInt("order_index", j + 1)
                            )
                        )
                    }
                    remoteTests.add(
                        TestItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                            title = obj.optString("title", ""),
                            durationMinutes = obj.optInt("duration_minutes", 30),
                            isActive = obj.optBoolean("is_active", true),
                            questions = qList,
                            createdAt = obj.optString("created_at", "")
                        )
                    )
                }
                synchronized(this@SupabaseRepository) {
                    localTests.clear()
                    localTests.addAll(remoteTests)
                    saveTestsToCache()
                }
            }
            response.close()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Fetch tests error: ${e.message}")
        }

        // 4. Fetch Announcements from Supabase
        try {
            val url = "$supabaseUrl/rest/v1/announcements?select=*"
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .get()
                .build()
            val response = client.newCall(request).execute()
            if (response.isSuccessful) {
                val body = response.body?.string() ?: ""
                val array = JSONArray(body)
                val remoteAnnouncements = mutableListOf<AnnouncementItem>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    remoteAnnouncements.add(
                        AnnouncementItem(
                            id = obj.optString("id", UUID.randomUUID().toString()),
                            title = obj.optString("title", ""),
                            message = obj.optString("message", ""),
                            examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                            date = obj.optString("date", ""),
                            isActive = obj.optBoolean("is_active", true),
                            isImportant = obj.optBoolean("is_important", false)
                        )
                    )
                }
                synchronized(this@SupabaseRepository) {
                    localAnnouncements.clear()
                    localAnnouncements.addAll(remoteAnnouncements)
                    saveAnnouncementsToCache()
                }
            }
            response.close()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Fetch announcements error: ${e.message}")
        }
    }

    // --- Authentication Operations ---

    suspend fun login(mobile: String, password: String): AuthResult = withContext(Dispatchers.IO) {
        val trimmedMobile = mobile.trim()
        val trimmedPassword = password.trim()

        if (trimmedMobile.isEmpty() || trimmedPassword.isEmpty()) {
            return@withContext AuthResult.Error("કૃપા કરીને મોબાઇલ નંબર અને પાસવર્ડ દાખલ કરો.")
        }

        // 1. Try Supabase remote verification first
        if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
            try {
                val url = "$supabaseUrl/rest/v1/profiles?mobile=eq.$trimmedMobile&select=*"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()

                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val responseBody = response.body?.string() ?: ""
                    val jsonArray = JSONArray(responseBody)
                    if (jsonArray.length() > 0) {
                        val userObj = jsonArray.getJSONObject(0)
                        val isActive = userObj.optBoolean("is_active", true)
                        if (!isActive) {
                            response.close()
                            return@withContext AuthResult.Error("આ એકાઉન્ટ ઉપલબ્ધ નથી.")
                        }

                        val storedPassword = userObj.optString("password_hash", "")
                        if (storedPassword != trimmedPassword) {
                            response.close()
                            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
                        }

                        val sessionToken = UUID.randomUUID().toString()
                        val userProfile = UserProfile(
                            id = userObj.optString("id", UUID.randomUUID().toString()),
                            mobile = userObj.optString("mobile", trimmedMobile),
                            passwordHash = storedPassword,
                            fullName = userObj.optString("full_name", ""),
                            role = UserRole.fromString(userObj.optString("role", "student")),
                            examType = userObj.optString("exam_type", "").takeIf { it.isNotBlank() && it != "null" }?.let { ExamType.fromString(it) },
                            isActive = true,
                            sessionToken = sessionToken,
                            createdAt = userObj.optString("created_at", "")
                        )

                        // Update local cache
                        synchronized(this@SupabaseRepository) {
                            val existingIndex = localUsers.indexOfFirst { it.id == userProfile.id || it.mobile == userProfile.mobile }
                            if (existingIndex != -1) {
                                localUsers[existingIndex] = userProfile
                            } else {
                                localUsers.add(userProfile)
                            }
                            saveUsersToCache()
                        }

                        sessionManager.saveUserSession(userProfile, sessionToken)
                        updateRemoteSessionToken(userProfile.id, sessionToken)
                        response.close()
                        return@withContext AuthResult.Success(userProfile, sessionToken)
                    }
                }
                response.close()
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Remote login error, falling back to persistent cache: ${e.message}")
            }
        }

        // 2. Check local users list (Persistent Cache)
        val user = synchronized(this@SupabaseRepository) { localUsers.firstOrNull { it.mobile == trimmedMobile } }
        if (user == null) {
            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
        }

        if (!user.isActive) {
            return@withContext AuthResult.Error("આ એકાઉન્ટ ઉપલબ્ધ નથી.")
        }

        if (user.passwordHash != trimmedPassword) {
            return@withContext AuthResult.Error("મોબાઇલ નંબર અથવા પાસવર્ડ ખોટો છે.")
        }

        val sessionToken = UUID.randomUUID().toString()
        val activeUser = user.copy(sessionToken = sessionToken)

        synchronized(this@SupabaseRepository) {
            val index = localUsers.indexOfFirst { it.id == user.id }
            if (index != -1) {
                localUsers[index] = activeUser
                saveUsersToCache()
            }
        }

        sessionManager.saveUserSession(activeUser, sessionToken)
        AuthResult.Success(activeUser, sessionToken)
    }

    private fun updateRemoteSessionToken(userId: String, token: String) {
        try {
            if (supabaseUrl.isBlank() || supabaseKey.isBlank()) return
            val url = "$supabaseUrl/rest/v1/profiles?id=eq.$userId"
            val json = JSONObject().put("session_token", token)
            val body = json.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .addHeader("apikey", supabaseKey)
                .addHeader("Authorization", "Bearer $supabaseKey")
                .patch(body)
                .build()
            client.newCall(request).execute().close()
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Update session error: ${e.message}")
        }
    }

    fun getActiveSession(): UserProfile? {
        val user = sessionManager.getLoggedInUser() ?: return null
        val localUser = synchronized(this@SupabaseRepository) { localUsers.firstOrNull { it.id == user.id } }
        if (localUser != null && !localUser.isActive) {
            sessionManager.clearSession()
            return null
        }
        return localUser ?: user
    }

    fun logout() {
        sessionManager.clearSession()
    }

    suspend fun updateAdminPassword(adminId: String, oldPassword: String, newPassword: String): Result<Unit> = withContext(Dispatchers.IO) {
        val trimmedOld = oldPassword.trim()
        val trimmedNew = newPassword.trim()

        if (trimmedNew.length < 4) {
            return@withContext Result.failure(Exception("નવો પાસવર્ડ ઓછામાં ઓછો 4 અક્ષરનો હોવો જોઈએ."))
        }

        val admin = synchronized(this@SupabaseRepository) { localUsers.firstOrNull { it.id == adminId && it.role == UserRole.ADMIN } }
            ?: return@withContext Result.failure(Exception("એડમિન એકાઉન્ટ મળ્યું નથી."))

        if (admin.passwordHash != trimmedOld) {
            return@withContext Result.failure(Exception("હાલનો (જૂનો) પાસવર્ડ ખોટો છે."))
        }

        val updatedAdmin = admin.copy(passwordHash = trimmedNew)
        synchronized(this@SupabaseRepository) {
            val index = localUsers.indexOfFirst { it.id == adminId }
            if (index != -1) {
                localUsers[index] = updatedAdmin
                saveUsersToCache()
            }
        }
        sessionManager.saveUserSession(updatedAdmin, updatedAdmin.sessionToken ?: UUID.randomUUID().toString())

        // Update Supabase if configured
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/profiles?id=eq.$adminId"
                val json = JSONObject().put("password_hash", trimmedNew)
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .patch(body)
                    .build()
                client.newCall(request).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Update admin password remote error: ${e.message}")
        }

        Result.success(Unit)
    }

    // --- Student Features ---

    suspend fun getTestsForStudent(examType: ExamType): List<TestItem> = withContext(Dispatchers.IO) {
        // Sync with Supabase if online
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/tests?exam_type=eq.${examType.id}&is_active=eq.true&select=*,questions(*)"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val array = JSONArray(body)
                    val tests = mutableListOf<TestItem>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val qArray = obj.optJSONArray("questions") ?: JSONArray()
                        val qList = mutableListOf<QuestionItem>()
                        for (j in 0 until qArray.length()) {
                            val qObj = qArray.getJSONObject(j)
                            qList.add(
                                QuestionItem(
                                    id = qObj.optString("id", UUID.randomUUID().toString()),
                                    testId = qObj.optString("test_id", obj.optString("id")),
                                    questionText = qObj.optString("question_text", ""),
                                    optionA = qObj.optString("option_a", ""),
                                    optionB = qObj.optString("option_b", ""),
                                    optionC = qObj.optString("option_c", ""),
                                    optionD = qObj.optString("option_d", ""),
                                    correctOption = qObj.optInt("correct_option", 0),
                                    explanation = qObj.optString("explanation", ""),
                                    orderIndex = qObj.optInt("order_index", j + 1)
                                )
                            )
                        }
                        tests.add(
                            TestItem(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                examType = examType,
                                title = obj.optString("title", ""),
                                durationMinutes = obj.optInt("duration_minutes", 30),
                                isActive = true,
                                questions = qList,
                                createdAt = obj.optString("created_at", "")
                            )
                        )
                    }
                    response.close()
                    // Update cache for this exam type
                    synchronized(this@SupabaseRepository) {
                        localTests.removeAll { it.examType == examType }
                        localTests.addAll(tests)
                        saveTestsToCache()
                    }
                    return@withContext tests
                }
                response.close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Get tests for student error: ${e.message}")
        }

        // Return from persistent cache
        synchronized(this@SupabaseRepository) {
            localTests.filter { it.examType == examType && it.isActive }
        }
    }

    suspend fun getTestById(testId: String, studentExamType: ExamType?): TestItem? = withContext(Dispatchers.IO) {
        val test = synchronized(this@SupabaseRepository) { localTests.firstOrNull { it.id == testId } } ?: return@withContext null
        if (studentExamType != null) {
            if (test.examType != studentExamType || !test.isActive) {
                return@withContext null
            }
        }
        test
    }

    suspend fun getAnnouncementsForStudent(examType: ExamType): List<AnnouncementItem> = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            localAnnouncements.filter { it.examType == examType && it.isActive }
        }
    }

    // --- Admin Operations ---

    suspend fun getAllStudents(): List<UserProfile> = withContext(Dispatchers.IO) {
        // Refresh from remote if possible
        if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
            try {
                val url = "$supabaseUrl/rest/v1/profiles?role=eq.student&select=*"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val array = JSONArray(body)
                    val students = mutableListOf<UserProfile>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        students.add(
                            UserProfile(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                mobile = obj.optString("mobile", ""),
                                passwordHash = obj.optString("password_hash", ""),
                                fullName = obj.optString("full_name", ""),
                                role = UserRole.STUDENT,
                                examType = obj.optString("exam_type", "").takeIf { it.isNotBlank() && it != "null" }?.let { ExamType.fromString(it) },
                                isActive = obj.optBoolean("is_active", true),
                                sessionToken = obj.optString("session_token", "").takeIf { it.isNotBlank() && it != "null" },
                                createdAt = obj.optString("created_at", "")
                            )
                        )
                    }
                    response.close()
                    synchronized(this@SupabaseRepository) {
                        val admin = localUsers.firstOrNull { it.role == UserRole.ADMIN }
                        localUsers.clear()
                        if (admin != null) localUsers.add(admin)
                        localUsers.addAll(students)
                        saveUsersToCache()
                    }
                    return@withContext students
                }
                response.close()
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Get all students remote error: ${e.message}")
            }
        }
        synchronized(this@SupabaseRepository) {
            localUsers.filter { it.role == UserRole.STUDENT }
        }
    }

    suspend fun addStudent(
        fullName: String,
        mobile: String,
        password: String,
        examType: ExamType,
        isActive: Boolean = true
    ): Boolean = withContext(Dispatchers.IO) {
        val existing = synchronized(this@SupabaseRepository) { localUsers.firstOrNull { it.mobile == mobile } }
        if (existing != null) {
            return@withContext updateStudent(existing.id, fullName, mobile, password, examType, isActive)
        }

        val newStudent = UserProfile(
            id = UUID.randomUUID().toString(),
            mobile = mobile,
            passwordHash = password,
            fullName = fullName,
            role = UserRole.STUDENT,
            examType = examType,
            isActive = isActive,
            createdAt = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(java.util.Date())
        )

        synchronized(this@SupabaseRepository) {
            localUsers.add(newStudent)
            saveUsersToCache()
        }

        // Sync to Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/profiles"
                val json = JSONObject().apply {
                    put("id", newStudent.id)
                    put("mobile", newStudent.mobile)
                    put("password_hash", newStudent.passwordHash)
                    put("full_name", newStudent.fullName)
                    put("role", "student")
                    put("exam_type", newStudent.examType?.id)
                    put("is_active", newStudent.isActive)
                    put("created_at", newStudent.createdAt)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .addHeader("Prefer", "resolution=merge-duplicates")
                    .post(body)
                    .build()
                client.newCall(request).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Add student remote error: ${e.message}")
        }
        true
    }

    suspend fun updateStudent(
        id: String,
        fullName: String,
        mobile: String,
        password: String,
        examType: ExamType,
        isActive: Boolean
    ): Boolean = withContext(Dispatchers.IO) {
        var updatedStudent: UserProfile? = null
        synchronized(this@SupabaseRepository) {
            val index = localUsers.indexOfFirst { it.id == id }
            if (index != -1) {
                val old = localUsers[index]
                val updated = old.copy(
                    fullName = fullName,
                    mobile = mobile,
                    passwordHash = if (password.isNotBlank()) password else old.passwordHash,
                    examType = examType,
                    isActive = isActive
                )
                localUsers[index] = updated
                updatedStudent = updated
                saveUsersToCache()

                // Invalidate session if blocked
                if (!isActive && sessionManager.getLoggedInUser()?.id == id) {
                    sessionManager.clearSession()
                }
            }
        }

        if (updatedStudent != null) {
            // Sync update to Supabase server
            try {
                if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                    val url = "$supabaseUrl/rest/v1/profiles?id=eq.$id"
                    val json = JSONObject().apply {
                        put("mobile", updatedStudent!!.mobile)
                        put("password_hash", updatedStudent!!.passwordHash)
                        put("full_name", updatedStudent!!.fullName)
                        put("exam_type", updatedStudent!!.examType?.id)
                        put("is_active", updatedStudent!!.isActive)
                    }
                    val body = json.toString().toRequestBody("application/json".toMediaType())
                    val request = Request.Builder()
                        .url(url)
                        .addHeader("apikey", supabaseKey)
                        .addHeader("Authorization", "Bearer $supabaseKey")
                        .patch(body)
                        .build()
                    client.newCall(request).execute().close()
                }
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Update student remote error: ${e.message}")
            }
            return@withContext true
        }
        false
    }

    suspend fun deleteStudent(id: String): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            val index = localUsers.indexOfFirst { it.id == id }
            if (index != -1) {
                localUsers.removeAt(index)
                saveUsersToCache()
                if (sessionManager.getLoggedInUser()?.id == id) {
                    sessionManager.clearSession()
                }
            }
        }

        // Delete from Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/profiles?id=eq.$id"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(request).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Delete student remote error: ${e.message}")
        }
        true
    }

    suspend fun getAllTestsForAdmin(examTypeFilter: ExamType? = null): List<TestItem> = withContext(Dispatchers.IO) {
        // Refresh from Supabase if online
        if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
            try {
                val filterQuery = if (examTypeFilter != null) "exam_type=eq.${examTypeFilter.id}&" else ""
                val url = "$supabaseUrl/rest/v1/tests?${filterQuery}select=*,questions(*)"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val array = JSONArray(body)
                    val remoteTests = mutableListOf<TestItem>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        val qArray = obj.optJSONArray("questions") ?: JSONArray()
                        val qList = mutableListOf<QuestionItem>()
                        for (j in 0 until qArray.length()) {
                            val qObj = qArray.getJSONObject(j)
                            qList.add(
                                QuestionItem(
                                    id = qObj.optString("id", UUID.randomUUID().toString()),
                                    testId = qObj.optString("test_id", obj.optString("id")),
                                    questionText = qObj.optString("question_text", ""),
                                    optionA = qObj.optString("option_a", ""),
                                    optionB = qObj.optString("option_b", ""),
                                    optionC = qObj.optString("option_c", ""),
                                    optionD = qObj.optString("option_d", ""),
                                    correctOption = qObj.optInt("correct_option", 0),
                                    explanation = qObj.optString("explanation", ""),
                                    orderIndex = qObj.optInt("order_index", j + 1)
                                )
                            )
                        }
                        remoteTests.add(
                            TestItem(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                                title = obj.optString("title", ""),
                                durationMinutes = obj.optInt("duration_minutes", 30),
                                isActive = obj.optBoolean("is_active", true),
                                questions = qList,
                                createdAt = obj.optString("created_at", "")
                            )
                        )
                    }
                    response.close()
                    synchronized(this@SupabaseRepository) {
                        if (examTypeFilter != null) {
                            localTests.removeAll { it.examType == examTypeFilter }
                            localTests.addAll(remoteTests)
                        } else {
                            localTests.clear()
                            localTests.addAll(remoteTests)
                        }
                        saveTestsToCache()
                    }
                    return@withContext remoteTests
                }
                response.close()
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Get tests remote error: ${e.message}")
            }
        }

        synchronized(this@SupabaseRepository) {
            if (examTypeFilter != null) {
                localTests.filter { it.examType == examTypeFilter }
            } else {
                localTests.toList()
            }
        }
    }

    suspend fun toggleTestStatus(testId: String, isActive: Boolean): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            val index = localTests.indexOfFirst { it.id == testId }
            if (index != -1) {
                val old = localTests[index]
                localTests[index] = old.copy(isActive = isActive)
                saveTestsToCache()
            }
        }

        // Sync to Supabase
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/tests?id=eq.$testId"
                val json = JSONObject().apply {
                    put("is_active", isActive)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .patch(body)
                    .build()
                client.newCall(request).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Toggle test status remote error: ${e.message}")
        }
        true
    }

    suspend fun addOrUpdateTest(test: TestItem): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            val index = localTests.indexOfFirst { it.id == test.id }
            if (index != -1) {
                localTests[index] = test
            } else {
                localTests.add(0, test)
            }
            saveTestsToCache()
        }

        // Sync test & questions to Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                // 1. Upsert test
                val testUrl = "$supabaseUrl/rest/v1/tests"
                val testJson = JSONObject().apply {
                    put("id", test.id)
                    put("exam_type", test.examType.id)
                    put("title", test.title)
                    put("duration_minutes", test.durationMinutes)
                    put("is_active", test.isActive)
                    put("created_at", test.createdAt.ifEmpty { "2026-08-13" })
                }
                val testBody = testJson.toString().toRequestBody("application/json".toMediaType())
                val testReq = Request.Builder()
                    .url(testUrl)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .addHeader("Prefer", "resolution=merge-duplicates")
                    .post(testBody)
                    .build()
                client.newCall(testReq).execute().close()

                // 2. Delete existing questions for this test on remote
                val delQUrl = "$supabaseUrl/rest/v1/questions?test_id=eq.${test.id}"
                val delReq = Request.Builder()
                    .url(delQUrl)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(delReq).execute().close()

                // 3. Insert questions if any
                if (test.questions.isNotEmpty()) {
                    val qArray = JSONArray()
                    for (q in test.questions) {
                        val qObj = JSONObject().apply {
                            put("id", q.id)
                            put("test_id", test.id)
                            put("question_text", q.questionText)
                            put("option_a", q.optionA)
                            put("option_b", q.optionB)
                            put("option_c", q.optionC)
                            put("option_d", q.optionD)
                            put("correct_option", q.correctOption)
                            put("explanation", q.explanation)
                            put("order_index", q.orderIndex)
                        }
                        qArray.put(qObj)
                    }
                    val qUrl = "$supabaseUrl/rest/v1/questions"
                    val qBody = qArray.toString().toRequestBody("application/json".toMediaType())
                    val qReq = Request.Builder()
                        .url(qUrl)
                        .addHeader("apikey", supabaseKey)
                        .addHeader("Authorization", "Bearer $supabaseKey")
                        .post(qBody)
                        .build()
                    client.newCall(qReq).execute().close()
                }
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Add/Update test remote error: ${e.message}")
        }
        true
    }

    suspend fun deleteTest(testId: String): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            localTests.removeAll { it.id == testId }
            saveTestsToCache()
        }

        // Delete from Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                // Delete questions first
                val delQUrl = "$supabaseUrl/rest/v1/questions?test_id=eq.$testId"
                val qReq = Request.Builder()
                    .url(delQUrl)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(qReq).execute().close()

                // Delete test
                val delTestUrl = "$supabaseUrl/rest/v1/tests?id=eq.$testId"
                val tReq = Request.Builder()
                    .url(delTestUrl)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(tReq).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Delete test remote error: ${e.message}")
        }
        true
    }

    // --- Announcements Operations ---

    suspend fun getAllAnnouncementsForAdmin(examTypeFilter: ExamType? = null): List<AnnouncementItem> = withContext(Dispatchers.IO) {
        // Refresh from Supabase if online
        if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
            try {
                val filterQuery = if (examTypeFilter != null) "exam_type=eq.${examTypeFilter.id}&" else ""
                val url = "$supabaseUrl/rest/v1/announcements?${filterQuery}select=*"
                val request = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .get()
                    .build()
                val response = client.newCall(request).execute()
                if (response.isSuccessful) {
                    val body = response.body?.string() ?: ""
                    val array = JSONArray(body)
                    val remoteAnnouncements = mutableListOf<AnnouncementItem>()
                    for (i in 0 until array.length()) {
                        val obj = array.getJSONObject(i)
                        remoteAnnouncements.add(
                            AnnouncementItem(
                                id = obj.optString("id", UUID.randomUUID().toString()),
                                title = obj.optString("title", ""),
                                message = obj.optString("message", ""),
                                examType = ExamType.fromString(obj.optString("exam_type", "Navodaya")),
                                date = obj.optString("date", ""),
                                isActive = obj.optBoolean("is_active", true),
                                isImportant = obj.optBoolean("is_important", false)
                            )
                        )
                    }
                    response.close()
                    synchronized(this@SupabaseRepository) {
                        if (examTypeFilter != null) {
                            localAnnouncements.removeAll { it.examType == examTypeFilter }
                            localAnnouncements.addAll(remoteAnnouncements)
                        } else {
                            localAnnouncements.clear()
                            localAnnouncements.addAll(remoteAnnouncements)
                        }
                        saveAnnouncementsToCache()
                    }
                    return@withContext remoteAnnouncements
                }
                response.close()
            } catch (e: Exception) {
                Log.e("SupabaseRepo", "Get announcements remote error: ${e.message}")
            }
        }

        synchronized(this@SupabaseRepository) {
            if (examTypeFilter != null) {
                localAnnouncements.filter { it.examType == examTypeFilter }
            } else {
                localAnnouncements.toList()
            }
        }
    }

    suspend fun addOrUpdateAnnouncement(item: AnnouncementItem): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            val index = localAnnouncements.indexOfFirst { it.id == item.id }
            if (index != -1) {
                localAnnouncements[index] = item
            } else {
                localAnnouncements.add(0, item)
            }
            saveAnnouncementsToCache()
        }

        // Sync to Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/announcements"
                val json = JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("message", item.message)
                    put("exam_type", item.examType.id)
                    put("date", item.date)
                    put("is_active", item.isActive)
                    put("is_important", item.isImportant)
                }
                val body = json.toString().toRequestBody("application/json".toMediaType())
                val req = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .addHeader("Prefer", "resolution=merge-duplicates")
                    .post(body)
                    .build()
                client.newCall(req).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Add/Update announcement remote error: ${e.message}")
        }
        true
    }

    suspend fun deleteAnnouncement(id: String): Boolean = withContext(Dispatchers.IO) {
        synchronized(this@SupabaseRepository) {
            localAnnouncements.removeAll { it.id == id }
            saveAnnouncementsToCache()
        }

        // Delete from Supabase server
        try {
            if (supabaseUrl.isNotBlank() && supabaseKey.isNotBlank()) {
                val url = "$supabaseUrl/rest/v1/announcements?id=eq.$id"
                val req = Request.Builder()
                    .url(url)
                    .addHeader("apikey", supabaseKey)
                    .addHeader("Authorization", "Bearer $supabaseKey")
                    .delete()
                    .build()
                client.newCall(req).execute().close()
            }
        } catch (e: Exception) {
            Log.e("SupabaseRepo", "Delete announcement remote error: ${e.message}")
        }
        true
    }
}
