package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.ui.screens.ActiveTestScreen
import com.example.ui.screens.AdminDashboardScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.NoInternetScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.StudentMainContainer
import com.example.ui.screens.TestResultScreen
import com.example.ui.theme.TestMitraTheme
import com.example.viewmodel.AdminSection
import com.example.viewmodel.AppScreen
import com.example.viewmodel.TestMitraViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: TestMitraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            TestMitraTheme {
                val uiState by viewModel.uiState.collectAsState()
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(uiState.snackbarMessage) {
                    uiState.snackbarMessage?.let { message ->
                        snackbarHostState.showSnackbar(message)
                        viewModel.clearSnackbar()
                    }
                }

                // Handle Hardware Back Button logically
                BackHandler(enabled = true) {
                    when (uiState.currentScreen) {
                        is AppScreen.ActiveTest -> {
                            // Handled inside active test screen exit dialog
                            viewModel.exitTestToHome()
                        }
                        is AppScreen.TestResult -> {
                            viewModel.exitTestToHome()
                        }
                        is AppScreen.AdminDashboard -> {
                            if (uiState.adminCurrentSection != AdminSection.MAIN_MENU) {
                                viewModel.setAdminSection(AdminSection.MAIN_MENU)
                            } else {
                                finish()
                            }
                        }
                        else -> {
                            finish()
                        }
                    }
                }

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    contentWindowInsets = WindowInsets(0.dp),
                    snackbarHost = {
                        SnackbarHost(
                            hostState = snackbarHostState,
                            modifier = Modifier.safeDrawingPadding()
                        )
                    }
                ) { innerPadding ->
                    Crossfade(
                        targetState = uiState.currentScreen,
                        label = "screen_transition",
                        modifier = Modifier.fillMaxSize()
                    ) { screen ->
                        when (screen) {
                            is AppScreen.Splash -> {
                                SplashScreen()
                            }
                            is AppScreen.NoInternet -> {
                                NoInternetScreen(
                                    onRetry = { viewModel.retryInternetConnection() }
                                )
                            }
                            is AppScreen.Login -> {
                                LoginScreen(
                                    state = uiState,
                                    onMobileChange = { viewModel.onMobileChange(it) },
                                    onPasswordChange = { viewModel.onPasswordChange(it) },
                                    onTogglePasswordVisibility = { viewModel.togglePasswordVisibility() },
                                    onLoginClick = { viewModel.login() }
                                )
                            }
                            is AppScreen.StudentHome -> {
                                StudentMainContainer(
                                    state = uiState,
                                    onTabSelected = { viewModel.setStudentTab(it) },
                                    onStartTest = { viewModel.startTest(it) },
                                    onLogout = { viewModel.logout() }
                                )
                            }
                            is AppScreen.ActiveTest -> {
                                uiState.activeTestState?.let { attemptState ->
                                    ActiveTestScreen(
                                        attemptState = attemptState,
                                        selectedOption = uiState.selectedOptionForCurrentQuestion,
                                        isSubmitted = uiState.isAnswerSubmittedForCurrentQuestion,
                                        onOptionSelected = { viewModel.selectOption(it) },
                                        onSubmitAnswer = { viewModel.submitCurrentAnswer() },
                                        onNextQuestion = { viewModel.goToNextQuestion() },
                                        onPrevQuestion = { viewModel.goToPreviousQuestion() },
                                        onCompleteTest = { viewModel.completeTest() },
                                        onExit = { viewModel.exitTestToHome() }
                                    )
                                }
                            }
                            is AppScreen.TestResult -> {
                                TestResultScreen(
                                    state = screen.attemptState,
                                    onBackHome = { viewModel.exitTestToHome() }
                                )
                            }
                            is AppScreen.AdminDashboard -> {
                                AdminDashboardScreen(
                                    state = uiState,
                                    onNavigateSection = { viewModel.setAdminSection(it) },
                                    onSetExamFilter = { viewModel.setAdminExamFilter(it) },
                                    onSearchStudents = { viewModel.setAdminStudentSearchQuery(it) },
                                    onAddStudent = { name, mobile, pass, exam, active ->
                                        viewModel.addStudent(name, mobile, pass, exam, active)
                                    },
                                    onUpdateStudent = { id, name, mobile, pass, exam, active ->
                                        viewModel.updateStudent(id, name, mobile, pass, exam, active)
                                    },
                                    onDeleteStudent = { viewModel.deleteStudent(it) },
                                    onToggleTestStatus = { id, active -> viewModel.toggleTestStatus(id, active) },
                                    onSaveTest = { viewModel.addOrUpdateTest(it) },
                                    onDeleteTest = { viewModel.deleteTest(it) },
                                    onSaveAnnouncement = { viewModel.addOrUpdateAnnouncement(it) },
                                    onDeleteAnnouncement = { viewModel.deleteAnnouncement(it) },
                                    onChangeAdminPassword = { adminId, oldPass, newPass, callback ->
                                        viewModel.changeAdminPassword(adminId, oldPass, newPass, callback)
                                    },
                                    onLogout = { viewModel.logout() }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
