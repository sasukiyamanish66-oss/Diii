package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sleek Interface Primary & Accent Palette (Cool Slate & Vibrant Sky)
val TestMitraBlue = Color(0xFF0284C7)      // Sleek Sky 600
val TestMitraBlueDark = Color(0xFF0369A1)  // Sleek Sky 700
val TestMitraBlueLight = Color(0xFF0EA5E9) // Sleek Sky 500
val TestMitraSkySubtle = Color(0xFFE0F2FE) // Sky 100 container

val TestMitraGreen = Color(0xFF16A34A)     // Emerald 600
val TestMitraGreenLight = Color(0xFFDCFCE7)// Emerald 100
val TestMitraOrange = Color(0xFFD97706)    // Amber 600
val TestMitraOrangeLight = Color(0xFFFEF3C7)
val TestMitraRed = Color(0xFFDC2626)       // Red 600
val TestMitraRedLight = Color(0xFFFEE2E2)
val TestMitraPurple = Color(0xFF7C3AED)    // Violet 600
val TestMitraTeal = Color(0xFF0D9488)      // Teal 600

// Backgrounds & Surfaces (Sleek Cool Canvas)
val BackgroundLight = Color(0xFFF0F4F8)    // Sleek cool slate background (#F0F4F8)
val SurfaceLight = Color(0xFFFFFFFF)       // Crisp White surface
val SurfaceSlate = Color(0xFFF8FAFC)       // Slate 50 subtle container
val SurfaceHover = Color(0xFFF1F5F9)       // Slate 100

// Typography Colors
val TextPrimary = Color(0xFF0F172A)        // Slate 900
val TextSecondary = Color(0xFF475569)      // Slate 600
val TextMuted = Color(0xFF94A3B8)          // Slate 400
val BorderLight = Color(0xFFE2E8F0)        // Slate 200 border
val BorderMedium = Color(0xFFCBD5E1)       // Slate 300 border
val CardHighlight = Color(0xFFF1F5F9)

// Exam Category Themed Colors (Modern sleek tones)
val NavodayaColor = Color(0xFF4F46E5)      // Indigo 600
val NMMSColor = Color(0xFF0284C7)          // Sky 600
val GyanSetuColor = Color(0xFF7C3AED)      // Violet 600
val GyanSadhanaColor = Color(0xFF059669)   // Emerald 600
val TET1Color = Color(0xFFD97706)          // Amber 600

