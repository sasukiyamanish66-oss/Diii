package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AuthResult
import com.example.data.SupabaseRepository
import com.example.model.AnnouncementItem
import com.example.model.ExamType
import com.example.model.QuestionItem
import com.example.model.TestAttemptState
import com.example.model.TestItem
import com.example.model.UserProfile
import com.example.model.UserRole
import com.example.util.NetworkUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

sealed class AppScreen {
    data object Splash : AppScreen()
    data object NoInternet : AppScreen()
    data object Login : AppScreen()
    data object StudentHome : AppScreen()
    data class ActiveTest(val test: TestItem) : AppScreen()
    data class TestResult(val attemptState: TestAttemptState) : AppScreen()
    data object AdminDashboard : AppScreen()
}

enum class StudentTab {
    HOME,
    ANNOUNCEMENTS,
    PROFILE
}

enum class AdminSection {
    MAIN_MENU,
    STUDENT_MANAGEMENT,
    TEST_MANAGEMENT,
    EXAM_TYPE_MANAGEMENT,
    ANNOUNCEMENT_MANAGEMENT,
    ADMIN_PROFILE
}

data class UiState(
    val currentScreen: AppScreen = AppScreen.Splash,
    val isOnline: Boolean = true,
    val currentUser: UserProfile? = null,
    val studentSelectedTab: StudentTab = StudentTab.HOME,
    val adminCurrentSection: AdminSection = AdminSection.MAIN_MENU,

    // Login state
    val loginMobile: String = "",
    val loginPassword: String = "",
    val isPasswordVisible: Boolean = false,
    val isLoggingIn: Boolean = false,
    val loginErrorMessage: String? = null,

    // Student Data
    val studentTests: List<TestItem> = emptyList(),
    val studentAnnouncements: List<AnnouncementItem> = emptyList(),
    val isLoadingStudentData: Boolean = false,

    // Active Test State
    val activeTestState: TestAttemptState? = null,
    val selectedOptionForCurrentQuestion: Int? = null,
    val isAnswerSubmittedForCurrentQuestion: Boolean = false,

    // Admin Data
    val adminStudents: List<UserProfile> = emptyList(),
    val adminTests: List<TestItem> = emptyList(),
    val adminAnnouncements: List<AnnouncementItem> = emptyList(),
    val adminSelectedExamFilter: ExamType? = null,
    val adminStudentSearchQuery: String = "",
    val isLoadingAdminData: Boolean = false,

    // Feedback Toast / Snackbar
    val snackbarMessage: String? = null
)

class TestMitraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SupabaseRepository(application)
    private val _uiState = MutableStateFlow(UiState())
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var testTimerJob: Job? = null

    init {
        checkInitialState()
        observeNetwork()
    }

    private fun observeNetwork() {
        viewModelScope.launch {
            NetworkUtils.observeNetworkState(getApplication()).collect { online ->
                _uiState.update { it.copy(isOnline = online) }
                if (!online && _uiState.value.currentScreen !is AppScreen.Splash) {
                    _uiState.update { it.copy(currentScreen = AppScreen.NoInternet) }
                }
            }
        }
    }

    private fun checkInitialState() {
        viewModelScope.launch {
            val isOnline = NetworkUtils.isOnline(getApplication())
            _uiState.update { it.copy(isOnline = isOnline) }

            delay(1800) // Splash animation duration

            if (!isOnline) {
                _uiState.update { it.copy(currentScreen = AppScreen.NoInternet) }
                return@launch
            }

            val savedSession = repository.getActiveSession()
            if (savedSession != null) {
                _uiState.update { it.copy(currentUser = savedSession) }
                if (savedSession.role == UserRole.ADMIN) {
                    loadAdminData()
                    _uiState.update { it.copy(currentScreen = AppScreen.AdminDashboard) }
                } else {
                    loadStudentData(savedSession.examType ?: ExamType.NAVODAYA)
                    _uiState.update { it.copy(currentScreen = AppScreen.StudentHome) }
                }
            } else {
                _uiState.update { it.copy(currentScreen = AppScreen.Login) }
            }
        }
    }

    fun retryInternetConnection() {
        viewModelScope.launch {
            val isOnline = NetworkUtils.isOnline(getApplication())
            _uiState.update { it.copy(isOnline = isOnline) }
            if (isOnline) {
                val savedSession = repository.getActiveSession()
                if (savedSession != null) {
                    _uiState.update { it.copy(currentUser = savedSession) }
                    if (savedSession.role == UserRole.ADMIN) {
                        loadAdminData()
                        _uiState.update { it.copy(currentScreen = AppScreen.AdminDashboard) }
                    } else {
                        loadStudentData(savedSession.examType ?: ExamType.NAVODAYA)
                        _uiState.update { it.copy(currentScreen = AppScreen.StudentHome) }
                    }
                } else {
                    _uiState.update { it.copy(currentScreen = AppScreen.Login) }
                }
            } else {
                showSnackbar("કૃપા કરીને ઇન્ટરનેટ કનેક્શન તપાસો.")
            }
        }
    }

    // --- Login Form Actions ---

    fun onMobileChange(value: String) {
        _uiState.update { it.copy(loginMobile = value, loginErrorMessage = null) }
    }

    fun onPasswordChange(value: String) {
        _uiState.update { it.copy(loginPassword = value, loginErrorMessage = null) }
    }

    fun togglePasswordVisibility() {
        _uiState.update { it.copy(isPasswordVisible = !it.isPasswordVisible) }
    }

    fun login() {
        val mobile = _uiState.value.loginMobile
        val password = _uiState.value.loginPassword

        if (mobile.isBlank() || password.isBlank()) {
            _uiState.update { it.copy(loginErrorMessage = "કૃપા કરીને મોબાઇલ નંબર અને પાસવર્ડ દાખલ કરો.") }
            return
        }

        viewModelScope.launch {
            if (!NetworkUtils.isOnline(getApplication())) {
                _uiState.update { it.copy(currentScreen = AppScreen.NoInternet) }
                return@launch
            }

            _uiState.update { it.copy(isLoggingIn = true, loginErrorMessage = null) }
            when (val result = repository.login(mobile, password)) {
                is AuthResult.Success -> {
                    val user = result.user
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            currentUser = user,
                            loginMobile = "",
                            loginPassword = "",
                            loginErrorMessage = null
                        )
                    }

                    if (user.role == UserRole.ADMIN) {
                        loadAdminData()
                        _uiState.update { it.copy(currentScreen = AppScreen.AdminDashboard) }
                    } else {
                        val studentExamType = user.examType ?: ExamType.NAVODAYA
                        loadStudentData(studentExamType)
                        _uiState.update { it.copy(currentScreen = AppScreen.StudentHome) }
                    }
                }
                is AuthResult.Error -> {
                    _uiState.update {
                        it.copy(
                            isLoggingIn = false,
                            loginErrorMessage = result.message
                        )
                    }
                }
            }
        }
    }

    fun logout() {
        testTimerJob?.cancel()
        testTimerJob = null
        repository.logout()
        _uiState.update {
            it.copy(
                currentUser = null,
                currentScreen = AppScreen.Login,
                studentSelectedTab = StudentTab.HOME,
                adminCurrentSection = AdminSection.MAIN_MENU,
                activeTestState = null
            )
        }
    }

    // --- Student Actions ---

    fun setStudentTab(tab: StudentTab) {
        _uiState.update { it.copy(studentSelectedTab = tab) }
    }

    private fun loadStudentData(examType: ExamType) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingStudentData = true) }
            try {
                val tests = repository.getTestsForStudent(examType)
                val announcements = repository.getAnnouncementsForStudent(examType)
                _uiState.update {
                    it.copy(
                        studentTests = tests,
                        studentAnnouncements = announcements,
                        isLoadingStudentData = false
                    )
                }
            } catch (e: Exception) {
                _uiState.update { it.copy(isLoadingStudentData = false) }
            }
        }
    }

    fun startTest(test: TestItem) {
        if (!test.isActive) {
            showSnackbar("આ ટેસ્ટ હાલમાં ઉપલબ્ધ નથી.")
            return
        }

        val totalSeconds = test.durationMinutes * 60
        val attemptState = TestAttemptState(
            test = test,
            currentQuestionIndex = 0,
            timeRemainingSeconds = totalSeconds
        )

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.ActiveTest(test),
                activeTestState = attemptState,
                selectedOptionForCurrentQuestion = null,
                isAnswerSubmittedForCurrentQuestion = false
            )
        }

        startTestTimer()
    }

    private fun startTestTimer() {
        testTimerJob?.cancel()
        testTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                val currentAttempt = _uiState.value.activeTestState ?: break
                if (currentAttempt.timeRemainingSeconds <= 1) {
                    // Time up - automatically submit
                    completeTest()
                    break
                }
                _uiState.update {
                    it.copy(
                        activeTestState = currentAttempt.copy(
                            timeRemainingSeconds = currentAttempt.timeRemainingSeconds - 1
                        )
                    )
                }
            }
        }
    }

    fun selectOption(optionIndex: Int) {
        val state = _uiState.value.activeTestState ?: return
        if (state.answeredConfirmed[state.currentQuestionIndex] == true) {
            // Already submitted for this question
            return
        }
        _uiState.update { it.copy(selectedOptionForCurrentQuestion = optionIndex) }
    }

    fun submitCurrentAnswer() {
        val state = _uiState.value.activeTestState ?: return
        val selected = _uiState.value.selectedOptionForCurrentQuestion ?: return

        state.selectedAnswers[state.currentQuestionIndex] = selected
        state.answeredConfirmed[state.currentQuestionIndex] = true

        _uiState.update {
            it.copy(
                isAnswerSubmittedForCurrentQuestion = true
            )
        }
    }

    fun goToNextQuestion() {
        val state = _uiState.value.activeTestState ?: return
        val nextIndex = state.currentQuestionIndex + 1

        if (nextIndex >= state.test.questions.size) {
            completeTest()
        } else {
            val nextSelected = state.selectedAnswers[nextIndex]
            val nextSubmitted = state.answeredConfirmed[nextIndex] ?: false

            _uiState.update {
                it.copy(
                    activeTestState = state.copy(currentQuestionIndex = nextIndex),
                    selectedOptionForCurrentQuestion = nextSelected,
                    isAnswerSubmittedForCurrentQuestion = nextSubmitted
                )
            }
        }
    }

    fun goToPreviousQuestion() {
        val state = _uiState.value.activeTestState ?: return
        val prevIndex = state.currentQuestionIndex - 1
        if (prevIndex >= 0) {
            val prevSelected = state.selectedAnswers[prevIndex]
            val prevSubmitted = state.answeredConfirmed[prevIndex] ?: false

            _uiState.update {
                it.copy(
                    activeTestState = state.copy(currentQuestionIndex = prevIndex),
                    selectedOptionForCurrentQuestion = prevSelected,
                    isAnswerSubmittedForCurrentQuestion = prevSubmitted
                )
            }
        }
    }

    fun completeTest() {
        testTimerJob?.cancel()
        testTimerJob = null
        val state = _uiState.value.activeTestState ?: return
        val completedState = state.copy(isCompleted = true)

        _uiState.update {
            it.copy(
                currentScreen = AppScreen.TestResult(completedState),
                activeTestState = null
            )
        }
    }

    fun exitTestToHome() {
        testTimerJob?.cancel()
        testTimerJob = null
        _uiState.update {
            it.copy(
                currentScreen = AppScreen.StudentHome,
                activeTestState = null
            )
        }
    }

    // --- Admin Actions ---

    fun setAdminSection(section: AdminSection) {
        _uiState.update { it.copy(adminCurrentSection = section) }
    }

    fun setAdminExamFilter(examType: ExamType?) {
        _uiState.update { it.copy(adminSelectedExamFilter = examType) }
        loadAdminTests(examType)
        loadAdminAnnouncements(examType)
    }

    fun setAdminStudentSearchQuery(query: String) {
        _uiState.update { it.copy(adminStudentSearchQuery = query) }
    }

    fun loadAdminData() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingAdminData = true) }
            val students = repository.getAllStudents()
            val tests = repository.getAllTestsForAdmin(_uiState.value.adminSelectedExamFilter)
            val announcements = repository.getAllAnnouncementsForAdmin(_uiState.value.adminSelectedExamFilter)
            _uiState.update {
                it.copy(
                    adminStudents = students,
                    adminTests = tests,
                    adminAnnouncements = announcements,
                    isLoadingAdminData = false
                )
            }
        }
    }

    private fun loadAdminTests(examType: ExamType?) {
        viewModelScope.launch {
            val tests = repository.getAllTestsForAdmin(examType)
            _uiState.update { it.copy(adminTests = tests) }
        }
    }

    private fun loadAdminAnnouncements(examType: ExamType?) {
        viewModelScope.launch {
            val announcements = repository.getAllAnnouncementsForAdmin(examType)
            _uiState.update { it.copy(adminAnnouncements = announcements) }
        }
    }

    fun addStudent(fullName: String, mobile: String, password: String, examType: ExamType, isActive: Boolean) {
        viewModelScope.launch {
            val success = repository.addStudent(fullName, mobile, password, examType, isActive)
            if (success) {
                showSnackbar("વિદ્યાર્થી સફળતાપૂર્વક ઉમેરાયો.")
                loadAdminData()
            }
        }
    }

    fun updateStudent(id: String, fullName: String, mobile: String, password: String, examType: ExamType, isActive: Boolean) {
        viewModelScope.launch {
            val success = repository.updateStudent(id, fullName, mobile, password, examType, isActive)
            if (success) {
                showSnackbar("વિદ્યાર્થી માહિતી અપડેટ થઈ.")
                loadAdminData()
            }
        }
    }

    fun deleteStudent(id: String) {
        viewModelScope.launch {
            val success = repository.deleteStudent(id)
            if (success) {
                showSnackbar("વિદ્યાર્થી એકાઉન્ટ ડિલીટ કરવામાં આવ્યું.")
                loadAdminData()
            }
        }
    }

    fun toggleTestStatus(testId: String, isActive: Boolean) {
        viewModelScope.launch {
            repository.toggleTestStatus(testId, isActive)
            loadAdminTests(_uiState.value.adminSelectedExamFilter)
            showSnackbar(if (isActive) "ટેસ્ટ એક્ટિવ કરવામાં આવી." else "ટેસ્ટ ઇન-એક્ટિવ કરવામાં આવી.")
        }
    }

    fun addOrUpdateTest(test: TestItem) {
        viewModelScope.launch {
            repository.addOrUpdateTest(test)
            loadAdminTests(_uiState.value.adminSelectedExamFilter)
            showSnackbar("ટેસ્ટ સફળતાપૂર્વક સાચવવામાં આવી.")
        }
    }

    fun deleteTest(testId: String) {
        viewModelScope.launch {
            repository.deleteTest(testId)
            loadAdminTests(_uiState.value.adminSelectedExamFilter)
            showSnackbar("ટેસ્ટ ડિલીટ કરવામાં આવી.")
        }
    }

    fun addOrUpdateAnnouncement(item: AnnouncementItem) {
        viewModelScope.launch {
            repository.addOrUpdateAnnouncement(item)
            loadAdminAnnouncements(_uiState.value.adminSelectedExamFilter)
            showSnackbar("સૂચના સાચવવામાં આવી.")
        }
    }

    fun deleteAnnouncement(id: String) {
        viewModelScope.launch {
            repository.deleteAnnouncement(id)
            loadAdminAnnouncements(_uiState.value.adminSelectedExamFilter)
            showSnackbar("સૂચના ડિલીટ થઈ.")
        }
    }

    fun changeAdminPassword(adminId: String, oldPass: String, newPass: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val result = repository.updateAdminPassword(adminId, oldPass, newPass)
            result.fold(
                onSuccess = {
                    showSnackbar("પાસવર્ડ સફળતાપૂર્વક બદલાઈ ગયો.")
                    val updatedUser = repository.getActiveSession()
                    _uiState.update { it.copy(currentUser = updatedUser) }
                    onResult(true, "પાસવર્ડ સફળતાપૂર્વક બદલાઈ ગયો.")
                },
                onFailure = { error ->
                    val errorMsg = error.message ?: "પાસવર્ડ બદલવામાં સમસ્યા આવી."
                    showSnackbar(errorMsg)
                    onResult(false, errorMsg)
                }
            )
        }
    }

    fun showSnackbar(message: String) {
        _uiState.update { it.copy(snackbarMessage = message) }
    }

    fun clearSnackbar() {
        _uiState.update { it.copy(snackbarMessage = null) }
    }
}
